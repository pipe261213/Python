# -*- coding: utf-8 -*-
"""
Created on Wed Mar 13 18:47:46 2024

@author: Estudiante
"""

#Creación de un diccionario vacio
diccionario= {}
print(diccionario)

#Crear diccionario con datos
salarios= {
    "juan":2000000,"juana":3000000,"carlos":10000000,"patricia":1500000
    }
print(salarios)

#Operaciones con diccionarios
print(salarios["juan"])

#Adicionar datos en el diccionario
salarios["pepe"]=15000000
salarios["rosita"]=10000000
print(salarios)

#Modificar datos
salarios["juana"]=2000000
print(salarios)

#Eliminar datos diccionario
del(salarios["pepe"])
print(salarios)

#Podemos incluir un diccionario en otro diccionario
estudiantes={
    "pedro":[5,4,3,2,1,5],
    "maria":[5,5,5,5,5,5],
    "juan":[4,5,3,4,5,3],
    "erika":[4,1,1,4,5,5]
    }
print(estudiantes)
print(estudiantes["juan"])
