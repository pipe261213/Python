# -*- coding: utf-8 -*-
"""
Created on Wed Feb 28 20:31:42 2024

@author: Estudiante
"""
#Input de nombres
nombre1=input("Escriba el nombre del primer estudiante: ")
nombre2=input("Escriba el nombre del segundo estudiante: ")
nombre3=input("Escriba el nombre del tercero estudiante: ")
nombre4=input("Escriba el nombre del cuarto estudiante: ")
nombre5=input("Escriba el nombre del quinto estudiante: ")

#Lista nombres
listanombres=[nombre1,nombre2,nombre3,nombre4,nombre5]

#Elemento al final
listanombres.insert(5, "Juan")
print(listanombres)

#Extracción
ultimo=listanombres.pop(2)
print(ultimo)
print(listanombres)
