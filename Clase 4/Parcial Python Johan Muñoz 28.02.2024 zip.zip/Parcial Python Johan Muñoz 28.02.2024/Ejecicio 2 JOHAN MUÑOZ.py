# -*- coding: utf-8 -*-
"""
Created on Wed Feb 28 20:12:23 2024

@author: Estudiante
"""

diassemana=["Lunes", "Martes", "Miercoles", "Jueves", "Viernes", "Sabado", "Domingo"]
mesesaño=("Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio", "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre")

print(diassemana)
print(mesesaño)

mesesañolista=list(mesesaño)
union=diassemana+mesesañolista