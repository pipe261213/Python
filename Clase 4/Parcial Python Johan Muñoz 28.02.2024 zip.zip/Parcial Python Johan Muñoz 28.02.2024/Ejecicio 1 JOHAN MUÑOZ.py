# -*- coding: utf-8 -*-
"""
Created on Wed Feb 28 19:01:10 2024

@author: Estudiante
"""
#Nombres alumnos
alumno1=input("Escriba el nombre del primer alumno: ")
alumno2=input("Escriba el nombre del segundo alumno: ")
alumno3=input("Escriba el nombre del tercer alumno: ")

#Materias alumnos
materia1=input("Escriba la primera materia: " )
materia2=input("Escriba la segunda materia: " )
materia3=input("Escriba la tercera materia: " )

#Notas por materia por alumno

    #Alumno1
no1ma1al1=int(input(f"Escriba la primera nota para {alumno1}, en la materia {materia1}: "))
no2ma1al1=int(input(f"Escriba la segunda nota para {alumno1}, en la materia {materia1}: "))
no3ma1al1=int(input(f"Escriba la tercera nota para {alumno1}, en la materia {materia1}: "))

no1ma2al1=int(input(f"Escriba la primera nota para {alumno1}, en la materia {materia2}: "))
no2ma2al1=int(input(f"Escriba la segunda nota para {alumno1}, en la materia {materia2}: "))
no3ma2al1=int(input(f"Escriba la tercera nota para {alumno1}, en la materia {materia2}: "))

no1ma3al1=int(input(f"Escriba la primera nota para {alumno1}, en la materia {materia3}: "))
no2ma3al1=int(input(f"Escriba la segunda nota para {alumno1}, en la materia {materia3}: "))
no3ma3al1=int(input(f"Escriba la tercera nota para {alumno1}, en la materia {materia3}: "))

    #Alumno2
no1ma1al2=int(input(f"Escriba la primera nota para {alumno2}, en la materia {materia1}: "))
no2ma1al2=int(input(f"Escriba la segunda nota para {alumno2}, en la materia {materia1}: "))
no3ma1al2=int(input(f"Escriba la tercera nota para {alumno2}, en la materia {materia1}: "))

no1ma2al2=int(input(f"Escriba la primera nota para {alumno2}, en la materia {materia2}: "))
no2ma2al2=int(input(f"Escriba la segunda nota para {alumno2}, en la materia {materia2}: "))
no3ma2al2=int(input(f"Escriba la tercera nota para {alumno2}, en la materia {materia2}: "))

no1ma3al2=int(input(f"Escriba la primera nota para {alumno2}, en la materia {materia3}: "))
no2ma3al2=int(input(f"Escriba la segunda nota para {alumno2}, en la materia {materia3}: "))
no3ma3al2=int(input(f"Escriba la tercera nota para {alumno2}, en la materia {materia3}: "))

    #Alumno3
no1ma1al3=int(input(f"Escriba la primera nota para {alumno3}, en la materia {materia1}: "))
no2ma1al3=int(input(f"Escriba la segunda nota para {alumno3}, en la materia {materia1}: "))
no3ma1al3=int(input(f"Escriba la tercera nota para {alumno3}, en la materia {materia1}: "))

no1ma2al3=int(input(f"Escriba la primera nota para {alumno3}, en la materia {materia2}: "))
no2ma2al3=int(input(f"Escriba la segunda nota para {alumno3}, en la materia {materia2}: "))
no3ma2al3=int(input(f"Escriba la tercera nota para {alumno3}, en la materia {materia2}: "))

no1ma3al3=int(input(f"Escriba la primera nota para {alumno3}, en la materia {materia3}: "))
no2ma3al3=int(input(f"Escriba la segunda nota para {alumno3}, en la materia {materia3}: "))
no3ma3al3=int(input(f"Escriba la tercera nota para {alumno3}, en la materia {materia3}: "))

#Definitiva por materia Alumno
    #Alumno1
promema1al1=(no1ma1al1+no2ma1al1+no3ma1al1)/3
promema2al1=(no1ma2al1+no2ma2al1+no3ma2al1)/3
promema3al1=(no1ma3al1+no2ma3al1+no3ma3al1)/3

    #Alumno2
promema1al2=(no1ma1al2+no2ma1al2+no3ma1al2)/3
promema2al2=(no1ma2al2+no2ma2al2+no3ma2al2)/3
promema3al2=(no1ma3al2+no2ma3al2+no3ma3al2)/3

    #Alumno3
promema1al3=(no1ma1al3+no2ma1al3+no3ma1al3)/3
promema2al3=(no1ma2al3+no2ma2al3+no3ma2al3)/3
promema3al3=(no1ma3al3+no2ma3al3+no3ma3al3)/3

#Definitiva por Alumno
    #Alumno1
proal1=(promema1al1+promema2al1+promema3al1)/3
    #Alumno2
proal2=(promema1al2+promema2al2+promema3al2)/3
    #Alumno3
proal3=(promema1al3+promema2al3+promema3al3)/3

#Lista de notas alumnos con materia
listaal1=[alumno1,promema1al1,promema2al1,promema3al1]
listaal2=[alumno2,promema1al2,promema2al2,promema3al2]
listaal3=[alumno1,promema1al3,promema2al3,promema3al3]
print(listaal1)
print(listaal2)
print(listaal3)

#Lista de notas por materia
listama1=[promema1al1,promema1al2,promema1al3]
listama2=[promema2al1,promema2al2,promema2al3]
listama3=[promema3al1,promema3al2,promema3al3]
print(listama1)
print(listama2)
print(listama3)

#Tamaño listas
    #Lista de notas alumnos con materia
tamlistaal1=len(listaal1)
tamlistaal2=len(listaal2)
tamlistaal3=len(listaal3)

print(f"La lista del promedio del alumno {alumno1} tiene un tamaño de: {tamlistaal1}")
print(f"La lista del promedio del alumno {alumno2} tiene un tamaño de: {tamlistaal2}")
print(f"La lista del promedio del alumno {alumno3} tiene un tamaño de: {tamlistaal3}")

    #Lista de notas por materia
tamlistama1=len(listama1)
tamlistama2=len(listama2)
tamlistama3=len(listama3)

print(f"La lista del promedio de la materia {materia1} tiene un tamaño de: {tamlistama1}")
print(f"La lista del promedio de la materia {materia2} tiene un tamaño de: {tamlistama2}")
print(f"La lista del promedio de la materia {materia3} tiene un tamaño de: {tamlistama3}")
