# -*- coding: utf-8 -*-
"""
Created on Wed Apr 24 19:31:24 2024

@author: Estudiante
"""

"""
Funciones de orden superior:
    
        
"""
#Definir variable global:
def prueba(f):
    return f()/2
#Crear la función a mostrar:
def mostrar():
    return 1*15
#Almacenamiento de redultados:
imprima= prueba(mostrar)
print(imprima)


