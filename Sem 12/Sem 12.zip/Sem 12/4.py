# -*- coding: utf-8 -*-
"""
Created on Wed May 15 21:14:59 2024

@author: Estudiante
"""

x = 1
while x < 6:
  print(x)
  if x == 3:
    break
  x += 1