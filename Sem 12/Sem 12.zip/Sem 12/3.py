# -*- coding: utf-8 -*-
"""
Created on Wed May 15 20:56:33 2024

@author: Estudiante
"""

contador=1
num1=0
num2=0
num3=0
var=0
while (contador<4):
    var=int(input("Escribe un numero para multiplicarlo: "))
    if (num1>=1):
        var==num1
    elif (num2>=1):
        var==num2
    elif (num3>=1):
        var==num3
    break
    contador+=1


Numero = int(input("Escribe un numero"))
while Numero < 6:
  print(Numero)
  if Numero == 3:
    break
  Numero += 1