# -*- coding: utf-8 -*-
"""
Created on Wed May 15 18:51:52 2024

@author: Estudiante
"""
##Solución parcial
#1. Establecer las variables globales y definiciones.
carro1=50000000
carro2=70000000
carro3=100000000

moto1=50000000
moto2=100000000
moto3=200000000
moto4=15000000
moto5=65000000

    #   Definimos funciones orden superior

def liquida(f):
    return f()

def carcred1():
    return ((carro1/cuota)*0.035)+(carro1/cuota)
    
def carcred2():
    return ((carro2/cuota)*0.035)+(carro2/cuota)
    
def carcred3():
    return ((carro3/cuota)*0.035)+(carro3/cuota)

def motcred1():
    return((moto1/cuota)*0.04)+(moto1/cuota)

def motcred2():
    return((moto2/cuota)*0.04)+(moto2/cuota)

def motcred3():
    return((moto3/cuota)*0.04)+(moto3/cuota)

def motcred4():
    return((moto4/cuota)*0.04)+(moto4/cuota)

def motcred5():
    return((moto5/cuota)*0.04)+(moto5/cuota)

def alqularcar():
    return dias*250000

def alqularmot():
    return dias*150000

#2. Establecer Menú


#Es mejor hacer procesos de decision con numeros y no con strings, eso es para
#evitar el error del usuario, se toma que el va a hacer algo malo (asi es mejor)
#para programar
proceso=int(input("Escoga la opcion, siendo 1. Compra carro, 2. Compra moto, 3.Alquila carro, 4.Alquila moto: "))

#3.Condicionales

if (proceso==1):
    esco=int(input(f"Escoga el carro que desee: 1. Mazda {carro1},2. Toyota {carro2}, 3.Renault{carro3}: "))
    if(esco==1):
        mpago=int(input("Eliga el metodo de pago: 1.Credíto 2. Contado: "))
        if(mpago==1):
                cuota=int(input("Ingrese el numero de cuotas a pagar: "))
                pagar=liquida(carcred1)
                print(f"El valor a pagar es: {pagar}")
        elif(mpago==2):
                print("El valor a pagar es {carro1}")
        else:
                print("Ingrese un valor valido")
    elif(esco==2):
        mpago=int(input("Eliga el metodo de pago: 1.Credíto 2. Contado"))
    elif(esco==3):
        mpago=int(input("Eliga el metodo de pago: 1.Credíto 2. Contado"))
    else:
        print("Escriba una opccion valida")
elif (proceso==2):
    print("2")
    esco=int(input(f"Escoga la moto que desee: 1. AKT {moto1},2. Pulsar {moto2}, 3.Yahama{moto3}, 4.Susuki {moto4}, 5. x {moto5}"))
    if(esco==1):
        mpago=int(input("Eliga el metodo de pago: 1.Credíto 2. Contado"))
        if(mpago==1):
                cuota=int(input("Ingrese el numero de cuotas a pagar:"))
                pagar=liquida(motcred1)
                print(f"El valor a pagar es: {pagar}")
        elif(mpago==2):
                print("El valor a pagar es {moto1}")
        else:
                print("Ingrese un valor valido")
    elif(esco==2):
        mpago=int(input("Eliga el metodo de pago: 1.Credíto 2. Contado"))
    elif(esco==3):
        mpago=int(input("Eliga el metodo de pago: 1.Credíto 2. Contado"))
    elif(esco==4):
        mpago=int(input("Eliga el metodo de pago: 1.Credíto 2. Contado"))
    elif(esco==5):
        mpago=int(input("Eliga el metodo de pago: 1.Credíto 2. Contado"))
    else:
        print("Escriba una opccion valida")
elif (proceso==3):
    dias=int(input("Digite el numero de días que desea alquilar el carro: "))
    pagaralq=liquida(alqularcar())
    print(f"El valor a pagar del alquilar de {dias} dias es de {pagaralq}")

elif (proceso==4):
    dias=int(input("Digite el numero de días que desea alquilar la moto: "))
    pagaralq=liquida(alqularmot())
    print(f"El valor a pagar del alquilar de {dias} dias es de {pagaralq}")
else:
    print("Digite una opcion valida")
