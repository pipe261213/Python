# -*- coding: utf-8 -*-
"""
Created on Wed May 15 19:52:30 2024

@author: Estudiante
"""

#Establecer variables globales
carro1=50000000
carro2=70000000
carro3=100000000
 
moto1=5000000
moto2=10000000
moto3=20000000
moto4=30000000
moto5=40000000
 
 
#Definimos funciones orden superior
def liquida(f):
    return f()
 
def carcred1():
    return ((carro1/cuota)*0.035)+(carro1/cuota)
 
def carcred2():
    return ((carro2/cuota)*0.035)+(carro2/cuota)
 
def carcred3():
    return ((carro3/cuota)*0.035)+(carro3/cuota)
 
def motcred1():
    return ((moto1/cuota)*0.04)+(moto1/cuota)
 
def motcred2():
    return ((moto2/cuota)*0.04)+(moto2/cuota)
 
def motcred3():
    return ((moto3/cuota)*0.04)+(moto3/cuota)
 
def motcred4():
    return ((moto4/cuota)*0.04)+(moto4/cuota)
 
def motcred5():
    return ((moto5/cuota)*0.04)+(moto5/cuota)
 
def alquilacar():
    return dias * 250000
 
def alquilamot():
    return dias * 150000
 
# Establecer menu
 
proceso=(int(input("Digite que opcion desea adquirir, 1. Compra carro 2.Compra moto 3. Alquila carro 4. Alquila moto: ")))
 
#condicionales
 
if(proceso==1):
    print("Escoja que carro desea comprar: ")
    esco=int(input(f"1.Mazda {carro1}, 2.Renault {carro2} 3.Fiat{carro3}: "))
    if(esco==1):
        mpago=int(input("Escoja metodo de pago 1.Credito    2.Contado: "))
        if(mpago==1):
            cuota=int(input("Digite número de cuotas a pagar: "))
            pagar=liquida(carcred1)
            print(f"El valor a pagar es: {pagar}")
        elif(mpago==2):
            print(f"El valor a pagar es {carro1}")
    elif(esco==2):
        mpago=int(input("Escoja metodo de pago 1.Credito    2.Contado: "))
        if(mpago==1):
            cuota=int(input("Digite número de cuotas a pagar: "))
            pagar=liquida(carcred2)
            print(f"El valor a pagar es: {pagar}")
        elif(mpago==2):
            print(f"El valor a pagar es {carro2}")
    elif(esco==3):
        mpago=int(input("Escoja metodo de pago 1.Credito    2.Contado: "))
        if(mpago==1):
            cuota=int(input("Digite número de cuotas a pagar: "))
            pagar=liquida(carcred3)
            print(f"El valor a pagar es: {pagar}")
        elif(mpago==2):
            print(f"El valor a pagar es {carro3}")
    else:
        print("Opcion no valida")

elif(proceso==2):
    print("Escoja que moto desea comprar: ")
    esco=int(input(f"1.akt {moto1}, 2.Pulsar {moto2} 3.yamaha{moto3} 4.yamaha{moto4} 5.yamaha{moto5}: "))
    if(esco==1):
        mpago=int(input("Escoja metodo de pago 1.Credito    2.Contado: "))
        if(mpago==1):
            cuota=int(input("Digite número de cuotas a pagar: "))
            pagar=liquida(motcred1)
            print(f"El valor a pagar es: {pagar}")
        elif(mpago==2):
            print(f"El valor a pagar es {moto1}")
    elif(esco==2):
        mpago=int(input("Escoja metodo de pago 1.Credito    2.Contado: "))
        if(mpago==1):
            cuota=int(input("Digite número de cuotas a pagar: "))
            pagar=liquida(motcred2)
            print(f"El valor a pagar es: {pagar}")
        elif(mpago==2):
            print(f"El valor a pagar es {moto2}")
    elif(esco==3):
        mpago=int(input("Escoja metodo de pago 1.Credito    2.Contado: "))
        if(mpago==1):
            cuota=int(input("Digite número de cuotas a pagar: "))
            pagar=liquida(motcred3)
            print(f"El valor a pagar es: {pagar}")
        elif(mpago==2):
            print(f"El valor a pagar es {moto3}")
    elif(esco==4):
        mpago=int(input("Escoja metodo de pago 1.Credito    2.Contado: "))
        if(mpago==1):
            cuota=int(input("Digite número de cuotas a pagar: "))
            pagar=liquida(motcred4)
            print(f"El valor a pagar es: {pagar}")
        elif(mpago==2):
            print(f"El valor a pagar es {moto4}")
    elif(esco==5):
        mpago=int(input("Escoja metodo de pago 1.Credito    2.Contado: "))
        if(mpago==1):
            cuota=int(input("Digite número de cuotas a pagar: "))
            pagar=liquida(motcred5)
            print(f"El valor a pagar es: {pagar}")
        elif(mpago==2):
            print(f"El valor a pagar es {moto5}")
    else:
        print("Opcion no valida")
elif(proceso==3):
    dias=int(input("Digite el número de días que desea alquilar el carro: "))
    pagaralq=liquida(alquilacar)
    print(f"El valor a pagar del alquiler de {dias} dias es de {pagaralq}")
elif(proceso==4):
    dias=int(input("Digite el número de días que desea alquilar la moto: "))
    pagaralq=liquida(alquilamot)
    print(f"El valor a pagar del alquiler de {dias} dias es de {pagaralq}")
else:
    print("Opcion invalida")