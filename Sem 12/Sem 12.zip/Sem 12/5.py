# -*- coding: utf-8 -*-
"""
Created on Wed May 15 21:18:48 2024

@author: Estudiante
"""
num=int(input("Escriba un numero para contar hacia el: "))
x = 1
while x <= num:
  print(x)
  x += 1
else:
    print("Proceso finalizado")