# -*- coding: utf-8 -*-
"""
Created on Wed Mar 20 18:44:08 2024

@author: Estudiante
"""
#Punto 1

diccionario={
    "Messi":["psg","argentino",5000000],
    "James":["sp","colombiano",200000],
    "Toko Koga":["feyenoord","japones",3500000],
    "Lina Caicedo":["real madrid","colombiana",1000000],
    "Rico Lewis":["manchester city","ingles",2300000],
    "David Møller Wolfe":["Alkmaar","noruego",3200000],
    "Lamine Yamal":["barcelona fc","español",3800000],
    "Leny Yoro":["lille","frances",4700000],
    "Arthur Vermeeren":["antwerp","belga",4600000],
    "Ariel Mosór":["Piast Gliwice","polaco",4100000]
    }
print(diccionario)

inputfutbolista=input("ingrese el nombre de un nuevo futbolista: ")
inputequiponuevofut=input(f"Ahora ingrese el equipo de {inputfutbolista}: ")
inputnacionalidadnuevofut=input(f"Ahora ingrese la nacionalidad de {inputfutbolista}: ")
inputvalornuevofut=int(input(f"Ahora ingrese el valor del {inputfutbolista}: "))
diccionario[inputfutbolista]=[inputequiponuevofut,inputnacionalidadnuevofut,inputvalornuevofut]

print(diccionario)

