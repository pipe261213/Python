# -*- coding: utf-8 -*-
"""
Created on Wed Mar 20 20:25:51 2024

@author: Estudiante
"""

#Punto 2
diccionarionotas={
    }
inputnombre1=input("ingrese el nombre del estudiante 1: ")
inputnom1nota1=int(input(f"Ahora ingrese la primera nota del estudiante {inputnombre1}:"))
inputnom1nota2=int(input(f"Ahora ingrese la segunda nota del estudiante {inputnombre1}:"))
inputnom1nota3=int(input(f"Ahora ingrese la tercera nota del estudiante {inputnombre1}:"))
inputnom1nota4=int(input(f"Ahora ingrese la cuarta nota del estudiante {inputnombre1}:"))
inputnom1nota5=int(input(f"Ahora ingrese la quinta nota del estudiante {inputnombre1}:"))
diccionarionotas[inputnombre1]=[inputnom1nota1,inputnom1nota2,inputnom1nota3,inputnom1nota4,inputnom1nota5]
print(diccionarionotas)

inputnombre2=input("ingrese el nombre del estudiante 2: ")
inputnom2nota1=int(input(f"Ahora ingrese la primera nota del estudiante {inputnombre2}:"))
inputnom2nota2=int(input(f"Ahora ingrese la segunda nota del estudiante {inputnombre2}:"))
inputnom2nota3=int(input(f"Ahora ingrese la tercera nota del estudiante {inputnombre2}:"))
inputnom2nota4=int(input(f"Ahora ingrese la cuarta nota del estudiante {inputnombre2}:"))
inputnom2nota5=int(input(f"Ahora ingrese la quinta nota del estudiante {inputnombre2}:"))
diccionarionotas[inputnombre2]=[inputnom2nota1,inputnom2nota2,inputnom2nota3,inputnom2nota4,inputnom2nota5]
print(diccionarionotas)

inputnombre3=input("ingrese el nombre del estudiante 3: ")
inputnom3nota1=int(input(f"Ahora ingrese la primera nota del estudiante {inputnombre3}:"))
inputnom3nota2=int(input(f"Ahora ingrese la segunda nota del estudiante {inputnombre3}:"))
inputnom3nota3=int(input(f"Ahora ingrese la tercera nota del estudiante {inputnombre3}:"))
inputnom3nota4=int(input(f"Ahora ingrese la cuarta nota del estudiante {inputnombre3}:"))
inputnom3nota5=int(input(f"Ahora ingrese la quinta nota del estudiante {inputnombre3}:"))
diccionarionotas[inputnombre3]=[inputnom3nota1,inputnom3nota2,inputnom3nota3,inputnom3nota4,inputnom3nota5]
print(diccionarionotas)

promedionom1=(inputnom1nota1+inputnom1nota2+inputnom1nota3+inputnom1nota4+inputnom1nota5)/5
promedionom2=(inputnom2nota1+inputnom2nota2+inputnom2nota3+inputnom2nota4+inputnom2nota5)/5
promedionom3=(inputnom3nota1+inputnom3nota2+inputnom3nota3+inputnom3nota4+inputnom3nota5)/5

print(f"El promedio de las notas de {inputnombre1} es de: {promedionom1}")
print(f"El promedio de las notas de {inputnombre2} es de: {promedionom2}")
print(f"El promedio de las notas de {inputnombre3} es de: {promedionom3}")