# -*- coding: utf-8 -*-
"""
Created on Wed Mar 20 21:05:51 2024

@author: Estudiante
"""

# -*- coding: utf-8 -*-
"""
Created on Wed Mar 20 19:54:23 2024

@author: Estudiante
"""

#Punto 3
empleados={
    }
empleado1="empleado1"
nomempleado1="juan"
idempleado1=1
edadempleado1=28
nacionalidadempleado1="Español"
emailempleado1="a@gmail.com"
hijosempleado1={
    }
nomhijoempleado1='Roberto'
edadhijoempleado1=12
sexohijoempleado1='Hombre'
hijosempleado1[nomempleado1]=[nomhijoempleado1,edadhijoempleado1,sexohijoempleado1]
empleados[empleado1]=[nomempleado1,idempleado1,edadempleado1,nacionalidadempleado1,
                      emailempleado1,hijosempleado1]

empleado2="empleado2"
nomempleado2='Marta'
idempleado2=2
edadempleado2=23
nacionalidadempleado2='Colombiana'
emailempleado2='b@gmail.com'
hijosempleado2={
    }
nomhijoempleado2='Maria'
edadhijoempleado2=17
sexohijoempleado2='Mujer'
hijosempleado2[nomempleado2]=[nomhijoempleado2,edadhijoempleado2,sexohijoempleado2]
empleados[empleado2]=[nomempleado2,idempleado2,edadempleado2,nacionalidadempleado2,
                      emailempleado2,hijosempleado2]

print(empleados)