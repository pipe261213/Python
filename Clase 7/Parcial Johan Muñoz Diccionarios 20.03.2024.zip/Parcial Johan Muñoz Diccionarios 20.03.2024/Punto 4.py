# -*- coding: utf-8 -*-
"""
Created on Wed Mar 20 20:26:07 2024

@author: Estudiante
"""

#Nota 4
conjunto1=set()
materias=set()
notas=set()
carreras=set()
conjunto1={'Python','Arquitectura moderna','Movimiento en el lienzo',5,4,3,'Programación','Arquitectura','Artes plasticas'}
materias={'Python','Arquitectura moderna','Movimiento en el lienzo'}
notas={5,4,3}
carreras={'Programación','Arquitectura','Artes plasticas'}
print(conjunto1)

print(materias.issubset(notas))
print(not(notas.issubset(carreras)))