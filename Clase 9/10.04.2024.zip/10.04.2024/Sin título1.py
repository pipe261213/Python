# -*- coding: utf-8 -*-
"""
Created on Wed Apr 10 20:06:05 2024

@author: Estudiante
"""

n1=int(input('digite la primera nota:'))
n2=int(input('digite la segunda nota:'))
n3=int(input('digite la tecera nota:'))
n4=int(input('digite la cuarta nota:'))
prom=(n1+n2+n3+n4)/4


if(prom >= 4):
    print('Excelente')
elif(prom >= 3):
    print('Paso')
elif(prom >= 2):
    print('Perdio')    
else:
    print('Le van a pegar')
    