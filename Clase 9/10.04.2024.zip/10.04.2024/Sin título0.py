# -*- coding: utf-8 -*-
"""
Created on Wed Apr 10 19:21:21 2024

@author: Estudiante
"""

a=5
b=1
if(not a==5):
    print('No es igual a 5')

else:
    print('Es igual a 5')
    
n1=int(input('digite la primera nota:'))
n2=int(input('digite la primera nota:'))
n3=int(input('digite la primera nota:'))

res=(n1+n2+n3)/3

if(res >= 3):
    print(f'Paso la materia y su definitiva es{res}')
else:
    print(f'No paso la materia y su definitiva es: {res}')
    
a=1
b=1
if(a>5):
    print('Es mayor a 5')
elif(a==5):
    print('Es igual a 5')
else:
    print('Es menor a 5')