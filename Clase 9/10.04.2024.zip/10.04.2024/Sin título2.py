# -*- coding: utf-8 -*-
"""
Created on Wed Apr 10 20:57:23 2024

@author: Estudiante
"""

a=int(input('Digite nota 1: '))
b=int(input('Digite nota 2: '))
c=int(input('Digite nota 3: '))

if(a>5 or b>5 or c>5):
    print('Digite un valor valido de 0 a 5')

else:
    
    prome=(a+b+c)/3
    
    if(prome >= 4):
        print(f'Excelente, su nota es: {prome}')
    elif(prome >= 3):
        print(f'Paso, su nota es: {prome}')
    elif(prome >= 2):
        print(f'Perdio, su nota es: {prome}')    
    else:
        print(f'Le van a pegar, su nota es: {prome}')