# -*- coding: utf-8 -*-
"""
Created on Wed Apr  3 19:17:09 2024

@author: Estudiante
"""

conjunto1=set()
tamaño={'Grande','Pequeño','Mediano'}
conjunto1=tamaño

conjunto2=set()
presentacion={'individual','paquete'}
conjunto2=presentacion

conjunto1=frozenset(tamaño)
conjunto2=frozenset(presentacion)

diccionario={'Caja de galletas':{conjunto1,conjunto2},
             'Caja de chicles':{conjunto1,conjunto2},
             'Cinta 100 mts':{conjunto1,conjunto2},
             'Colbon':{conjunto1,conjunto2},
             'Jet':{conjunto1,conjunto2},
             'Mapa Colombia':{conjunto1,conjunto2},
             'tijeras':{conjunto1,conjunto2},
             'alcohol':{conjunto1,conjunto2}}

print(conjunto1)

print(diccionario)

# En el ejercicio se realizo algo similar al parcial
# solo que está vez en vez de diccionario se uso un conjunto
# ademas se adiciono un frozenset, el cual permite que los datos
# del conjunto se congelen, lo anterior fue realizado así a causa de
# el siguiente error que aparecia en consola:
# TypeError: unhashable type: 'set'