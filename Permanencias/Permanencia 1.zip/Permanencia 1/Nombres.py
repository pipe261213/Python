# -*- coding: utf-8 -*-
"""
Created on Tue May 28 18:17:50 2024

@author: Estudiante
"""

añonac=int(input("Digite el año de su nacimiento: "))
nombre=input("Ingrese su nombre: ")
edad= 2024-añonac

for x in range(1,edad +1):
    print(x,nombre)
    
print("///////////////////////////////////")

y=1

while y <= edad:
    print(y,nombre)
    y=y+1