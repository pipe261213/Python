# -*- coding: utf-8 -*-
"""
Created on Tue May 28 18:15:03 2024

@author: Estudiante
"""

numeroin=25
limite=10

for i in range(1, limite + 1):
        resultado = numeroin * i
        print(f"{numeroin} x {i} = {resultado}")

print("/////////////////")



x=1
while x <= limite:
    resultado2 = numeroin * x
    print(f"{numeroin} x {x} = {resultado2}")
    x=x+1