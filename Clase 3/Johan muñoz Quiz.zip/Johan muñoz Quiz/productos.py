# -*- coding: utf-8 -*-
"""
Created on Wed Feb 21 20:21:23 2024

@author: Estudiante
"""

print('Productos:')
p1=input("Escriba el primer producto:")
p2=input("Escriba el segundo producto:")
p3=input("Escriba el tecer producto:")
lproductos=[p1,p2,p3]

print(lproductos)
valor1=int(input(f'Escriba el valor del producto {p1}: '))
valor2=int(input(f'Escriba el valor del producto {p2}: '))
valor3=int(input(f'Escriba el valor del producto {p3}: '))
valores=[valor1,valor2,valor3]
print(valores)

listafinal=lproductos+valores
print(listafinal)