# -*- coding: utf-8 -*-
"""
Created on Wed Feb 21 19:59:39 2024

@author: Estudiante
"""
print('Base de un triangulo:')
base=int(input('Inserte la base del triangulo'))
altura=int(input('Inserte la altura del triangulo'))
area=(base*altura)/2
listaarea=[base,altura,area]
print(listaarea)

