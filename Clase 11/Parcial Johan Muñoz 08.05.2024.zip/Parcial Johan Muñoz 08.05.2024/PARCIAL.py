# -*- coding: utf-8 -*-
"""
Created on Wed May  8 18:53:03 2024

@author: Estudiante
"""
"""
1. Crear una aplicación de orden superior que pida al usuario que proceso desea seguir, los procesos son los siguientes:

a. Comprar Carro.

b. Comprar Moto.

c. Alquilar carro.

d. Alquilar moto.

2. De acuerdo a la opcion que escoja realizar.

a. SI escoje Comprar carro le debe mostrar 3 opciones de carro con su respectivo precio, y de acuerdo al que escoja debe escoger 
si lo paga a credito o de contado, si es credito debe pedirle numero de cuotas y cada cuota se le incrementara el 3.5% de interes 
sobre capital, si es contado el valor a pagar solamente es el valor del vehiculo escogido.

b SI escoje Comprar moto le debe mostrar 5 opciones de moto con su respectivo precio, y de acuerdo al que escoja debe escoger 
si lo paga a credito o de contado, si es credito debe pedirle numero de cuotas y cada cuota se le incrementara el 4% de interes 
sobre capital, si es contado el valor a pagar solamente es el valor del vehiculo escogido.

c. Si escoge alquiler de carro debe pedir la cantidad de dias a alquilar y de acuerdo a ello multiplica el valor de $250.000 por dia y da el total a pagar.

d. Si escoge alquiler de moto debe pedir la cantidad de dias a alquilar y de acuerdo a ello multiplica el valor de $150.000 por dia y da el total a pagar.
"""
"""
Operaciones matematicas son con funciones de orden superior, los condicionales son para los arboles de decision, primero hacer los if y leufgo ahacer las fucniones de orden superior
"""
comprar_carro=1
comprar_moto=2
alquilar_carro=3
alquilar_moto=4
valor=0
porccarro=float(0.035)
pormoto=float(0.04)
dias_alq=0
opciones_carro={
    "SUV C3 Aircross":[120000000,1],"Nissan Kicks X-Play III":[150000000,2],"Kwid E-Tech 100% eléctrico":[135000000,3],
    }
opciones_moto={
    "BENELLI_IMPERIALE 400":[100000000,1],"VICTORY ZONTES 350 X1":[110000000,2],"KAWASAKI VERSYS 300 ABS":[90000000,3]
    }
opcion=float(input("Escriba el numero según la opción seleccionada, siendo 1 Comprar carro, 2 Comprar moto, 3 Alquilar carro, 4 Alquilar moto: "))
mensaje1="A continuación se imprime el modelo del vehiculo, luego su precio y al finalizar el numero que debe escribir para elegir dicha opcion"
if(opcion==comprar_carro):
    print("Usted ha seleccionado comprar carro")
    print(mensaje1)
    modelo=float(input(opciones_carro))
    opcion2=float(input("Digite por favor 1 para pagar de contado y 2 para pagar a cuotas"))
    if modelo==1:
        valor=120000000
    elif modelo==2:
        valor=150000000
    elif modelo==3:
        valor=135000000
    if(opcion2==1):
        print(f"El valor que debe pagar es {valor}")
    elif(opcion2==2):
        print(f"El valor de su compra es de: {valor}")
        opcion3=float(input("Digite el numero de cuotas a las que quiere diferir la compra"))
        def padre(f):
            return f()
        def valor_cuota():
            return valor/opcion3
        def cuota_capital():
            return valor_cuota()*porccarro
        def suma():
            return cuota_capital()+valor_cuota()
        print(f"El valor que debe pagar es {suma}")
    else:
        print("Seleccione una opcion valida")
elif(opcion==comprar_moto):
    print("Usted ha seleccionado comprar moto")
    print(mensaje1)
    modelo=float(input(opciones_moto))
    opcion2=float(input("Digite por favor 1 para pagar de contado y 2 para pagar a cuotas"))
    if modelo==1:
        valor=100000000
    elif modelo==2:
        valor=110000000
    elif modelo==3:
        valor=90000000
    if(opcion2==1):
        print(f"El valor que debe pagar es {valor}")
    elif(opcion2==2):
        print(f"El valor de su compra es de: {valor}")
        opcion3=float(input("Digite el numero de cuotas a las que quiere diferir la compra"))
        def padre(f):
            return f()
        def valor_cuota():
            return valor/opcion3
        def cuota_capital():
            return valor_cuota()*pormoto
        def suma():
            return cuota_capital()+valor_cuota()
        print(f"El valor que debe pagar es {suma}")
    else:
        print("Seleccione una opcion valida")
    
elif(opcion==alquilar_moto):
    print("Usted ha seleccionado alquilar moto")
    print(mensaje1)
    modelo=int(input(opciones_carro))
    dias_alq=int(input("Digite los diás que va a pedir la moto prestada"))
    def padre(f):
        return f()
    def alquiler_moto():
        return dias_alq*150000
    imprimir1=padre(alquiler_moto)
    print(f"El valor que debe pagar es {imprimir1}")
elif(opcion==alquilar_carro):
    print("Usted ha seleccionado alquilar carro")
    print(mensaje1)
    modelo=int(input(opciones_carro))
    dias_alq=int(input("Digite los diás que va a pedir el carro prestado"))
    def padre(f):
        return f()
    def alquiler_carro():
        return dias_alq*250000
    imprimir1=padre(alquiler_carro)
    print(imprimir1)
    print(f"El valor que debe pagar es {imprimir1}")
else: 
    print("Seleccione una opcion valida")

    
